Status	online
Type	kvm
Operating System	Linux Ubuntu 22 X86 64 Custom Gen2 V1
Nodename	EPYCROMEJP3
Hostname	GreenCloud.1733214488 
Main IP Address	62.106.70.2
IP Addresses	2403:71c0:2000:a013::4ab2
IPv6 Subnets	2403:71c0:2000:a013::/64
Root Password	
YJ2Oaf6BQa0I93zw8z
  
Boot Order	
ISO	
Rescue Mode	Off 
Bandwidth	627.25 MB of 750 GB Used / 749.39 GB Free
0%
Memory	
2 GB
HDD	
22 GB
CPU(s)	
2